// ============================================================
// ChatRequest.java
// ============================================================
package com.vidaplena.backend.dto;

import java.util.List;
import java.util.Map;

public class ChatRequest {
    private List<Map<String, String>> messages;

    public List<Map<String, String>> getMessages() { return messages; }
    public void setMessages(List<Map<String, String>> messages) { this.messages = messages; }
}


// ============================================================
// ChatResponse.java
// ============================================================
package com.vidaplena.backend.dto;

public class ChatResponse {
    private String reply;

    public ChatResponse(String reply) { this.reply = reply; }

    public String getReply() { return reply; }
    public void setReply(String reply) { this.reply = reply; }
}
