package com.vidaplena.backend.controller;

import com.vidaplena.backend.dto.ChatRequest;
import com.vidaplena.backend.dto.ChatResponse;
import com.vidaplena.backend.service.ClaudeService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin(origins = "*") // En producción: restringe a tu dominio Azure
public class ChatController {

    private final ClaudeService claudeService;

    public ChatController(ClaudeService claudeService) {
        this.claudeService = claudeService;
    }

    @PostMapping
    public ResponseEntity<ChatResponse> chat(@RequestBody ChatRequest request) {
        String reply = claudeService.sendMessage(request.getMessages());
        return ResponseEntity.ok(new ChatResponse(reply));
    }

    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("VidaPlena API activa ✅");
    }
}
