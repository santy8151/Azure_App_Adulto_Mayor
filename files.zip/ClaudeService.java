package com.vidaplena.backend.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;

@Service
public class ClaudeService {

    @Value("${anthropic.api.key}")
    private String apiKey;

    @Value("${anthropic.model:claude-sonnet-4-5}")
    private String model;

    private static final String ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";

    private static final String SYSTEM_PROMPT = """
        Eres "VidaPlena", un asistente virtual de salud y bienestar para adultos mayores en Colombia.
        
        PERSONALIDAD:
        - Habla siempre con calidez, amabilidad y paciencia
        - Usa lenguaje claro y sencillo, sin tecnicismos
        - Sé empático con preocupaciones de salud
        - Anima y motiva constantemente
        
        PUEDES AYUDAR CON:
        - Recordatorios de medicamentos y citas médicas
        - Consejos de salud y bienestar para adultos mayores
        - Ejercicios suaves apropiados para su edad
        - Nutrición y alimentación saludable
        - Compañía y conversación para bienestar emocional
        
        IMPORTANTE:
        - Si reportan síntomas graves (dolor pecho, dificultad para respirar), indica llamar al 123 inmediatamente
        - NUNCA reemplaces el consejo médico profesional
        - Respuestas concisas, máximo 150 palabras
        - Contexto: Colombia, sistema EPS
        """;

    private final HttpClient httpClient = HttpClient.newHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();

    public String sendMessage(List<Map<String, String>> messages) {
        try {
            Map<String, Object> body = Map.of(
                "model", model,
                "max_tokens", 600,
                "system", SYSTEM_PROMPT,
                "messages", messages
            );

            String jsonBody = objectMapper.writeValueAsString(body);

            HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(ANTHROPIC_URL))
                .header("Content-Type", "application/json")
                .header("x-api-key", apiKey)
                .header("anthropic-version", "2023-06-01")
                .POST(HttpRequest.BodyPublishers.ofString(jsonBody))
                .build();

            HttpResponse<String> response = httpClient.send(
                request, HttpResponse.BodyHandlers.ofString()
            );

            if (response.statusCode() != 200) {
                throw new RuntimeException("Error API Anthropic: " + response.statusCode());
            }

            Map<?, ?> responseMap = objectMapper.readValue(response.body(), Map.class);
            List<?> content = (List<?>) responseMap.get("content");
            Map<?, ?> firstBlock = (Map<?, ?>) content.get(0);
            return (String) firstBlock.get("text");

        } catch (Exception e) {
            return "Lo siento, tuve un problema para procesar tu solicitud. Por favor intenta de nuevo. 🙏";
        }
    }
}
